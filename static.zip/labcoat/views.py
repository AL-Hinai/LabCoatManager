from django.shortcuts import render
from .models import LabCoatInventory, LabCoatAddStock, LabCoatDistribution, InventoryUpdate
from django.http import HttpResponseRedirect
from django.db.models import Q
import plotly.graph_objs as go
from plotly.offline import plot
from collections import defaultdict
from datetime import datetime
import pandas as pd
from django.http import HttpResponse
from django.db import IntegrityError


# Home View
def home_view(request):
    return render(request, 'LabCoat/home.html')

# Stock View
def stock_view(request):
    # Prepare data for the graph
    updates_data = defaultdict(list)

    # Get all inventory updates ordered by timestamp
    inventory_updates = InventoryUpdate.objects.all().order_by('timestamp')

    for update in inventory_updates:
        # Append the update quantity and timestamp to updates_data
        updates_data[update.size].append((update.timestamp, update.quantity_update))

    # Create traces for the graph, one for each size
    graph_data = []
    for size, updates in updates_data.items():
        timestamps, quantities = zip(*updates) if updates else ([], [])
        size_display = dict(InventoryUpdate.SIZE_CHOICES)[size]
        graph_data.append(go.Scatter(
            x=timestamps,
            y=quantities,
            mode='lines+markers',
            name=size_display
        ))

    # Create the layout for the graph
    layout = go.Layout(
        title='Lab Coat Inventory Updates Over Time',
        xaxis=dict(title='Timestamp'),
        yaxis=dict(title='Quantity Updated'),
        showlegend=True
    )

    # Create the figure with data and layout
    figure = go.Figure(data=graph_data, layout=layout)

    # Generate the HTML representation of the plot
    graph_div = plot(figure, output_type='div')

    # Initialize current stock from LabCoatInventory
    current_stock = {}
    for inventory in LabCoatInventory.objects.all():
        size_display = inventory.get_size_display()  # Get the human-readable size name
        current_stock[size_display] = inventory.total

    # Pass both the graph and current stock data to the template
    return render(request, 'LabCoat/stock_view.html', {
        'graph_div': graph_div,
        'current_stock': current_stock
    })

# Add Stock View
def add_stock_view(request):
    if request.method == 'POST':
        size = request.POST.get('size')
        quantity = int(request.POST.get('quantity'))
        LabCoatAddStock.objects.create(size=size, quantity=quantity)
        return HttpResponseRedirect('/')
    return render(request, 'LabCoat/add_stock.html', {'sizes': LabCoatInventory.SIZE_CHOICES})

# Main View for Distributing Lab Coats
def distribute_lab_coat(request):
    sizes = LabCoatInventory.objects.values('size').distinct()

    if request.method == 'POST':
        size = request.POST.get('size')
        recipient_type = request.POST.get('recipient_type')
        quantity = int(request.POST.get('quantity', 0))
        distribution_date = request.POST.get('distribution_date', datetime.today().strftime('%Y-%m-%d'))

        # Convert the distribution date from string to datetime.date object
        try:
            distribution_date = datetime.strptime(distribution_date, '%Y-%m-%d').date()
        except ValueError:
            distribution_date = datetime.today().date()

        user_id = request.POST.get('user_id', '')
        name = request.POST.get('name', '')

        LabCoatDistribution.objects.create(
            size=size,
            recipient_type=recipient_type,
            quantity=quantity,
            user_id=user_id,
            name=name,
            date=distribution_date  # Use the provided or default date
        )
        return HttpResponseRedirect('/')

    return render(request, 'LabCoat/distribute_lab_coat.html', {'sizes': sizes})

# View for Students Distribute
def student_distributions_view(request):
    query = request.GET.get('search', '')
    distributions = LabCoatDistribution.objects.filter(recipient_type='student').filter(
        Q(user_id__icontains=query) | Q(name__icontains=query)
    )
    return render(request, 'LabCoat/student_distributions.html', {'distributions': distributions, 'query': query})

# View for Staff Distribute
def staff_distributions_view(request):
    query = request.GET.get('search', '')
    distributions = LabCoatDistribution.objects.filter(recipient_type='staff').filter(
        Q(user_id__icontains=query) | Q(name__icontains=query)
    )
    return render(request, 'LabCoat/staff_distributions.html', {'distributions': distributions, 'query': query})

def lab_coat_stock_chart(request):
    # Retrieve data from LabCoatInventory model
    inventory_data = LabCoatInventory.objects.all()

    # Prepare data for the line chart
    chart_data = {
        'timestamps': [],
        'sizes': ['Small', 'Medium', 'Large', 'Extra Large', 'Extra Extra Large'],
        'data': {
            'Small': [],
            'Medium': [],
            'Large': [],
            'Extra Large': [],
            'Extra Extra Large': [],
        },
    }

    # Fill chart_data with inventory data
    for item in inventory_data:
        chart_data['timestamps'].append(item.date)
        chart_data['data'][item.get_size_display()].append(item.total)

    return render(request, 'LabCoat/lab_coat_stock_chart.html', {'chart_data': chart_data})




def upload_excel_distribution(request):
    if request.method == 'POST' and request.FILES:
        excel_file = request.FILES['excel_file']

        # Read the Excel file
        df = pd.read_excel(excel_file, engine='openpyxl')

        # Process each row
        for _, row in df.iterrows():
            user_id = row['user_id']
            name = row['name']
            size = row['size']
            recipient_type = row['recipient_type']
            quantity = int(row['quantity'])
            date = pd.to_datetime(row['date']).date()

            try:
                # Attempt to get the LabCoatDistribution object using the unique criteria
                distribution_obj, created = LabCoatDistribution.objects.get_or_create(
                    user_id=user_id,
                    size=size,
                    date=date,
                    defaults={
                        'name': name,
                        'recipient_type': recipient_type,
                        'quantity': quantity
                    }
                )

                # Check if the object was created or already existed
                if created:
                    # Object was created, handle updates to inventory or other actions here
                    pass
                else:
                    # Object already existed, handle any updates or other logic here
                    pass
            except IntegrityError as e:
                # Handle any database integrity errors, such as duplicate entries
                pass

        return HttpResponse("Excel file processed successfully")

    # Render the template for GET requests
    return render(request, 'LabCoat/upload_excel_distribution.html')

